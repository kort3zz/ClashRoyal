<?php
require_once __DIR__ . '/../config/database.php';

class Auth {
    
    public function __construct() {
        // Не используем PDO в простой версии
    }
    
    // Проверка авторизации
    public function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }
    
    // Получение данных пользователя
    public function getUser() {
        if ($this->isLoggedIn()) {
            $user_id = $_SESSION['user_id'];
            foreach ($_SESSION['clash_users'] as $user) {
                if ($user['id'] == $user_id) {
                    // Не возвращаем пароль!
                    $user_data = $user;
                    unset($user_data['password']);
                    return $user_data;
                }
            }
        }
        return null;
    }
    
    // Регистрация
    public function register($username, $email, $password) {
        // Проверка существования
        foreach ($_SESSION['clash_users'] as $user) {
            if ($user['username'] === $username) {
                return ['success' => false, 'message' => 'Имя пользователя уже занято'];
            }
            if ($user['email'] === $email) {
                return ['success' => false, 'message' => 'Email уже используется'];
            }
        }
        
        // Создание нового пользователя
        $new_user = [
            'id' => count($_SESSION['clash_users']) + 1,
            'username' => $username,
            'email' => $email,
            'password' => $password, // Внимание: храним открытый пароль только для теста!
            'created_at' => date('Y-m-d H:i:s'),
            'last_login' => date('Y-m-d H:i:s'),
            'is_admin' => false
        ];
        
        // Добавляем пользователя
        $_SESSION['clash_users'][] = $new_user;
        
        // Автоматически логиним пользователя
        $_SESSION['user_id'] = $new_user['id'];
        
        return ['success' => true];
    }
    
    // Вход
    public function login($username, $password) {
        foreach ($_SESSION['clash_users'] as $user) {
            if (($user['username'] === $username || $user['email'] === $username) 
                && $user['password'] === $password) {
                
                $_SESSION['user_id'] = $user['id'];
                
                // Обновляем время последнего входа
                $user['last_login'] = date('Y-m-d H:i:s');
                
                return ['success' => true];
            }
        }
        
        return ['success' => false, 'message' => 'Неверное имя пользователя или пароль'];
    }
    
    // Выход
    public function logout() {
        unset($_SESSION['user_id']);
        session_destroy();
        return ['success' => true];
    }
}

// Создаем экземпляр Auth
$auth = new Auth();
?>