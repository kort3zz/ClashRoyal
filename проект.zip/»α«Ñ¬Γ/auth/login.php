<?php
// auth/login.php - УПРОЩЕННАЯ ВЕРСИЯ
session_start();

// Инициализируем пользователей если их нет
if (!isset($_SESSION['clash_users'])) {
    $_SESSION['clash_users'] = [
        [
            'id' => 1,
            'username' => 'admin',
            'email' => 'admin@clash.com',
            'password' => '123456',
            'is_admin' => true
        ]
    ];
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    // Поиск пользователя
    $found_user = null;
    foreach ($_SESSION['clash_users'] as $user) {
        if (($user['username'] === $username || $user['email'] === $username) 
            && $user['password'] === $password) {
            $found_user = $user;
            break;
        }
    }
    
    if ($found_user) {
        $_SESSION['user_id'] = $found_user['id'];
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Неверное имя пользователя или пароль';
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход | Clash Royale</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --gold: #FFD700; --dark: #0A1428; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: Arial, sans-serif; }
        body {
            background: linear-gradient(135deg, #0A1428 0%, #1a2a44 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            color: white;
        }
        .auth-box {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 20px;
            padding: 40px;
            width: 100%;
            max-width: 400px;
            border: 2px solid var(--gold);
        }
        .auth-header { text-align: center; margin-bottom: 30px; }
        .auth-header h1 { color: var(--gold); margin-bottom: 10px; font-size: 28px; }
        .error { background: rgba(255,70,85,0.1); color: #FF4655; padding: 15px; border-radius: 10px; margin-bottom: 20px; text-align: center; }
        .form-group { margin-bottom: 20px; }
        input { width: 100%; padding: 15px; background: rgba(255,255,255,0.1); border: 2px solid rgba(255,215,0,0.3); border-radius: 10px; color: white; font-size: 16px; }
        input:focus { outline: none; border-color: var(--gold); }
        button { width: 100%; padding: 16px; background: linear-gradient(45deg, var(--gold), #FFA500); color: var(--dark); border: none; border-radius: 10px; font-size: 16px; font-weight: bold; cursor: pointer; margin-top: 10px; }
        .links { text-align: center; margin-top: 20px; }
        .links a { color: var(--gold); text-decoration: none; margin: 0 10px; }
    </style>
</head>
<body>
    <div class="auth-box">
        <div class="auth-header">
            <h1><i class="fas fa-crown"></i> Вход</h1>
            <p>Войдите в свой аккаунт</p>
        </div>
        
        <?php if ($error): ?>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <input type="text" name="username" placeholder="Имя пользователя или Email" required>
            </div>
            
            <div class="form-group">
                <input type="password" name="password" placeholder="Пароль" required>
            </div>
            
            <button type="submit">
                <i class="fas fa-sign-in-alt"></i> Войти
            </button>
        </form>
        
        <div class="links">
            <p>
                <a href="register.php">Регистрация</a> | 
                <a href="../index.html">На главную</a>
            </p>
        </div>
        
        <div style="margin-top: 20px; font-size: 12px; color: #888; text-align: center;">
            Тестовый аккаунт: admin / 123456
        </div>
    </div>
</body>
</html>