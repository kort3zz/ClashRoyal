<?php
// auth/config/database.php - ПРОСТАЯ ВЕРСИЯ ДЛЯ TIMEWEB

// ВРЕМЕННОЕ РЕШЕНИЕ - используем массив в сессии вместо БД
session_start();

// Создаем массив пользователей если его нет
if (!isset($_SESSION['clash_users'])) {
    $_SESSION['clash_users'] = [
        [
            'id' => 1,
            'username' => 'admin',
            'email' => 'admin@clash.com',
            'password' => '123456', // В реальном проекте так НЕ делать!
            'created_at' => date('Y-m-d H:i:s'),
            'last_login' => null,
            'is_admin' => true
        ]
    ];
}

// Создаем PDO объект как null (не используется в простой версии)
$pdo = null;

// Проверяем, активна ли сессия
if (!session_id()) {
    session_start();
}

// Функция для хеширования пароля (имитация)
function simple_hash($password) {
    return md5($password); // Только для теста! В реальном проекте используйте password_hash()
}
?>