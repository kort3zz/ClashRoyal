<?php
// auth/dashboard.php
session_start();

if (!isset($_SESSION['user_id']) || !isset($_SESSION['clash_users'])) {
    header('Location: login.php');
    exit;
}

// Находим пользователя
$current_user = null;
foreach ($_SESSION['clash_users'] as $user) {
    if ($user['id'] == $_SESSION['user_id']) {
        $current_user = $user;
        break;
    }
}

if (!$current_user) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет | Clash Royale</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --gold: #FFD700; --purple: #8A2BE2; --dark: #0A1428; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: Arial, sans-serif; }
        body {
            background: linear-gradient(135deg, var(--dark) 0%, #1a2a44 100%);
            min-height: 100vh;
            color: white;
            padding: 20px;
        }
        .container { max-width: 800px; margin: 0 auto; padding: 40px; }
        .user-card { background: rgba(255,255,255,0.05); border-radius: 20px; padding: 40px; border: 2px solid var(--gold); margin-bottom: 30px; }
        .user-avatar { width: 100px; height: 100px; background: linear-gradient(45deg, var(--gold), var(--purple)); border-radius: 50%; margin: 0 auto 20px; display: flex; align-items: center; justify-content: center; font-size: 40px; }
        .user-info { text-align: center; }
        .user-info h2 { color: var(--gold); margin-bottom: 10px; }
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-top: 30px; }
        .stat-item { background: rgba(255,255,255,0.05); padding: 20px; border-radius: 10px; text-align: center; }
        .buttons { text-align: center; margin-top: 30px; }
        .btn { display: inline-block; padding: 12px 30px; margin: 10px; border-radius: 8px; text-decoration: none; font-weight: bold; }
        .btn-primary { background: linear-gradient(45deg, var(--gold), #FFA500); color: var(--dark); }
        .btn-secondary { background: transparent; color: white; border: 2px solid var(--gold); }
    </style>
</head>
<body>
    <div class="container">
        <h1 style="text-align: center; color: var(--gold); margin-bottom: 40px;">
            <i class="fas fa-crown"></i> Личный кабинет
        </h1>
        
        <div class="user-card">
            <div class="user-avatar">
                <i class="fas fa-crown"></i>
            </div>
            
            <div class="user-info">
                <h2><?= htmlspecialchars($current_user['username']) ?></h2>
                <p><?= htmlspecialchars($current_user['email']) ?></p>
                
                <div class="stats">
                    <div class="stat-item">
                        <div>Статус</div>
                        <div style="color: var(--gold); font-weight: bold;">
                            <?= $current_user['is_admin'] ? '👑 Администратор' : '🎮 Игрок' ?>
                        </div>
                    </div>
                    
                    <div class="stat-item">
                        <div>Дата регистрации</div>
                        <div style="color: var(--gold); font-weight: bold;">
                            <?= isset($current_user['created_at']) ? date('d.m.Y', strtotime($current_user['created_at'])) : 'Неизвестно' ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="buttons">
            <a href="../index.html" class="btn btn-primary">
                <i class="fas fa-home"></i> На главную
            </a>
            <a href="../cards.html" class="btn btn-primary">
                <i class="fas fa-crown"></i> Все карты
            </a>
            <a href="logout.php" class="btn btn-secondary">
                <i class="fas fa-sign-out-alt"></i> Выйти
            </a>
        </div>
    </div>
</body>
</html>