<?php
// auth/check.php
session_start();

header('Content-Type: application/json');

$response = ['loggedIn' => false];

if (isset($_SESSION['user_id']) && isset($_SESSION['clash_users'])) {
    foreach ($_SESSION['clash_users'] as $user) {
        if ($user['id'] == $_SESSION['user_id']) {
            $response = [
                'loggedIn' => true,
                'user' => [
                    'id' => $user['id'],
                    'username' => $user['username'],
                    'email' => $user['email'],
                    'is_admin' => $user['is_admin'] ?? false
                ]
            ];
            break;
        }
    }
}

echo json_encode($response);
?>