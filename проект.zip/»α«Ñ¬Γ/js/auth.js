// Проверка статуса авторизации
async function checkAuthStatus() {
    try {
        const response = await fetch('auth/check.php');
        const data = await response.json();
        
        const authButtons = document.getElementById('authButtons');
        const userMenu = document.getElementById('userMenu');
        
        if (data.loggedIn) {
            // Пользователь авторизован
            authButtons.style.display = 'none';
            userMenu.style.display = 'flex';
            document.getElementById('userName').innerHTML = 
                `<i class="fas fa-user"></i> ${data.user.username}`;
        } else {
            // Пользователь не авторизован
            authButtons.style.display = 'flex';
            userMenu.style.display = 'none';
        }
    } catch (error) {
        console.log('Ошибка проверки авторизации:', error);
        // Показываем кнопки входа по умолчанию
        document.getElementById('authButtons').style.display = 'flex';
        document.getElementById('userMenu').style.display = 'none';
    }
}

// Проверяем при загрузке страницы
document.addEventListener('DOMContentLoaded', checkAuthStatus);